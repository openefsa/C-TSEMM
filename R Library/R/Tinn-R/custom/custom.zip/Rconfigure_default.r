
##===============================================================
## Tinn-R: necessary packages and functions
## Tinn-R: >= 2.2.0.2 with TinnR package >= 1.0.3
##===============================================================
## Set the URL of the preferred repository, below some examples:
options(repos='http://software.rc.fas.harvard.edu/mirrors/R/') # USA
#options(repos='http://cran.ma.imperial.ac.uk/') # UK
#options(repos='http://brieger.esalq.usp.br/CRAN/') # Brazil

library(utils)

## Check necessary packages
necessary <- c('TinnR', 'svSocket')
installed <- necessary %in% installed.packages()[, 'Package']
if (length(necessary[!installed]) >=1)
  install.packages(necessary[!installed])

## Load packages
library(TinnR)
library(svSocket)

## Uncoment the two lines below if you want Tinn-R to always start R at start-up
## (Observation: check the path of Tinn-R.exe)
#options(IDE='C:/Tinn-R/bin/Tinn-R.exe')
#trStartIDE()

## Set options
options(use.DDE=T)

## Start DDE
trDDEInstall()

.trPaths <- paste(paste(Sys.getenv('APPDATA'), '\\Tinn-R\\tmp\\', sep=''),
            c('', 'search.txt', 'objects.txt', 'file.r', 'selection.r', 'block.r', 'lines.r'), sep='')
